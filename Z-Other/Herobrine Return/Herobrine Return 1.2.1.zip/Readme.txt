
INFORMATION...
  This pack is usable with most Resource Packs. But If the pack has its own stone, door, or log models, They won't work if this is layered above

VERSIONS...
  1.14 to 1.18 Snapshots

 **IF THERE'S INCOMPATIBLE WARNING, JUST IGNORE IT. IT WILL BE FINE**


HOW TO INSTALL...
  1. Launch the game
  2. On the Game Main Menu, Go to 'Options... -> Resource Packs...'
  3. Click 'Open Pack Folder'
  4. Drag the Resource Packs file into the folder
  5. Now In Resource Packs Menu, Apply the resource pack.
  6. Enjoy the pack..

 **MAKE SURE THAT THIS IS ON TOP OF THE OTHER PACK**

LICENSE:
This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
https://creativecommons.org/licenses/by-sa/4.0/

With the appropriate credit and a link provided, You are allowed to share, edit, and use it in your video as much as you want.
However, the project must be distributed and released under the **same license** as the original pack.