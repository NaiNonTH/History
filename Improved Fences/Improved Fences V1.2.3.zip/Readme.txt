
INFORMATION...
  This pack is usable with any Resource Packs, but if those packs contain variated textures/models, it may not work properly.

VERSIONS...
  1.14 to 1.19

 **IF THERE'S INCOMPATIBLE WARNING, JUST IGNORE IT. IT WILL BE FINE**


HOW TO INSTALL...
  1. Launch the game
  2. On the Game Main Menu, Go to 'Options... -> Resource Packs...'
  3. Click 'Open Pack Folder'
  4. Drag the Resource Packs file into the folder
  5. Now In Resource Packs Menu, Apply the resource pack.
  6. Enjoy the pack..

 **MAKE SURE THAT THIS ADD-ON IS ON TOP OF THE OTHER PACK**

LICENSE:
This work is licensed under a Creative Commons Attribution 4.0 International License.
https://creativecommons.org/licenses/by/4.0/

With the appropriate credit and a link provided, You are allowed to share, edit and use it in your video publicly as much as you want.
However, under some of my additional conditions, *YOU MUST NOT SELL, CLAIM THIS RESOURCE PACK AS YOUR OWN, OR INCLUDE IN FALSE ADVERTISING.*